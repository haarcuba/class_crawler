class Throwing:
    def __init__(self, exception_class):
        self.exception_class = exception_class

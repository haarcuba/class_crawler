from . import desdixexception
from . import argumentexpectations as argexp
from . import fake as fake_module
from . import DSL

_current_scenario = None
_MISS = object()


class _AwaitableResult:
    def __init__(self, value, on_await=None):
        self._value = value
        self._on_await = on_await

    def _resolve_value(self):
        if isinstance(self._value, DSL.Throwing):
            raise self._value.exception_class()
        return self._value

    def __await__(self):
        if self._on_await:
            self._on_await()
        return self._resolve_value()
        yield  # noqa: makes this a generator function


class _ContextManagerResult:
    def __init__(self, value, expectation):
        self._value = value
        self._expectation = expectation

    def __enter__(self):
        self._expectation.mark_cm_entered()
        if isinstance(self._value, DSL.Throwing):
            raise self._value.exception_class()
        return self._value

    def __exit__(self, *args):
        return False


class _AsyncContextManagerResult:
    def __init__(self, value, expectation):
        self._value = value
        self._expectation = expectation

    async def __aenter__(self):
        self._expectation.mark_cm_entered()
        if isinstance(self._value, DSL.Throwing):
            raise self._value.exception_class()
        return self._value

    async def __aexit__(self, *args):
        return False


class _AsyncIterator:
    def __init__(self, items):
        self._items = iter(items)

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return next(self._items)
        except StopIteration:
            raise StopAsyncIteration


_CT_BUILDERS = {
    'await': lambda v, e: _AwaitableResult(v, on_await=e.mark_awaited),
    'with': lambda v, e: _ContextManagerResult(v, e),
    'async_with': lambda v, e: _AsyncContextManagerResult(v, e),
}


class _Expectation:
    ORDERED = 'ordered'
    UNORDERED = 'unordered'

    def __init__(self, fake_obj, args, kwargs, mode=ORDERED, call_type='call'):
        self._fake, self._fake_name = fake_obj, object.__getattribute__(fake_obj, '_name')
        self._args, self._kwargs, self._mode, self._call_type = args, kwargs, mode, call_type
        self._everlasting = self._cm_entered = self._awaited = self._fulfilled = False
        self._return_value = self._throw_class = None
        self._hooks = []

    @property
    def fake_name(self):
        return self._fake_name

    def mark_cm_entered(self):
        self._cm_entered = True
        self._fulfilled = True

    def mark_awaited(self):
        self._awaited = True
        self._fulfilled = True

    def returns(self, value):
        self._return_value = value
        return self

    def throwing(self, exc_class):
        self._throw_class = exc_class
        return self

    def unordered(self):
        self._mode = self.UNORDERED
        return self

    def everlasting(self):
        self._everlasting = True
        return self

    def __rshift__(self, value):
        if isinstance(value, DSL.Throwing):
            self._throw_class = value.exception_class
        else:
            self._return_value = value
        return self

    def _arg_matches(self, expected, actual):
        if isinstance(expected, argexp._ArgumentExpectation):
            return expected.matches(actual)
        return expected == actual

    def _args_match(self, args, kwargs):
        exp_args = self._args
        if len(exp_args) == 1 and isinstance(exp_args[0], argexp.IgnoreCallDetails):
            return True
        if len(args) != len(exp_args) or self._kwargs != kwargs:
            return False
        return all(self._arg_matches(e, a) for e, a in zip(exp_args, args))

    def matches(self, fake_obj, args, kwargs):
        if fake_obj is not self._fake:
            return False
        return self._args_match(args, kwargs)

    def execute(self):
        if self._throw_class is not None:
            raise self._throw_class()
        return self._return_value

    def _wrapped_value(self):
        if self._throw_class:
            return DSL.Throwing(self._throw_class)
        return self._return_value

    def execute_with_result_wrapper(self, call_type_override=None):
        ct = call_type_override or self._call_type
        if ct == 'call':
            return self.execute()
        return _CT_BUILDERS[ct](self._wrapped_value(), self)

    def run_hooks(self):
        for h in self._hooks:
            h.run()

    def needs_enter_check(self):
        return self._call_type in ('with', 'async_with') and not self._cm_entered

    def needs_await_check(self):
        return self._call_type == 'await' and not self._awaited


class _AsyncForExpectation:
    def __init__(self, fake_obj, values):
        self._fake = fake_obj
        self._fake_name = object.__getattribute__(fake_obj, '_name')
        self._values = values

    def matches_fake(self, fake_obj):
        return fake_obj is self._fake

    def make_iterator(self):
        return _AsyncIterator(self._values)


_SPECIAL_MODES = {
    '__with__': 'with',
    '__await_on__': 'await',
    '__async_with__': 'async_with',
    '__async_for__': 'async_for',
}


class Scenario:
    def __init__(self, name=None):
        global _current_scenario
        if _current_scenario is not None:
            raise desdixexception.DesdixError('Only one scenario may exist at a time')
        self._name = name
        self._expectations, self._async_for_expectations = [], []
        self._had_expectation_error = False

    def __enter__(self):
        global _current_scenario
        _current_scenario = self
        fake_module._reset_all_user_attrs()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        global _current_scenario
        _current_scenario = None
        if exc_type is not None:
            return False
        self._verify()
        return False

    def _verify_cm_entered(self, exp):
        if not (exp._fulfilled and exp.needs_enter_check()):
            return
        enter = '__enter__' if exp._call_type == 'with' else '__aenter__'
        raise desdixexception.ScenarioException(
            f'{exp.fake_name} was called but never used with "with" statement (__enter__ = {enter})'
        )

    def _verify_awaited(self, exp):
        if not (exp._fulfilled and exp.needs_await_check()):
            return
        raise desdixexception.DesdixException(f'{exp.fake_name} was called but never awaited')

    def _verify_not_premature(self, exp):
        if self._had_expectation_error or exp._everlasting or exp._fulfilled:
            return
        raise desdixexception.ScenarioException(
            f'Scenario ended prematurely: expected {exp.fake_name}{exp._args} but got nothing'
        )

    def _check_exp(self, exp):
        self._verify_cm_entered(exp)
        self._verify_awaited(exp)
        self._verify_not_premature(exp)

    def _verify(self):
        for exp in self._expectations:
            if not isinstance(exp, _AsyncForExpectation):
                self._check_exp(exp)

    def __lshift__(self, h):
        if self._expectations:
            self._expectations[-1]._hooks.append(h)
        return self

    def __getattr__(self, name):
        if name in _SPECIAL_MODES:
            return _SpecialProxy(self, _SPECIAL_MODES[name])
        if name.startswith('_'):
            raise AttributeError(name)
        return _ScenarioProxy(self, name)

    def __dynamic__(self, name):
        return _ScenarioProxy(self, name, 'call')

    def __from_fake__(self, f):
        return _ScenarioProxy(self, object.__getattribute__(f, '_name'), 'call')

    def _add_expectation(self, exp):
        self._expectations.append(exp)
        return exp

    def _add_async_for(self, exp):
        self._async_for_expectations.append(exp)

    def _fulfill(self, exp):
        exp._fulfilled = True
        result = exp.execute_with_result_wrapper()
        exp.run_hooks()
        return result

    def _next_ordered(self):
        ordered = [e for e in self._expectations if e._mode == _Expectation.ORDERED]
        for e in ordered:
            if not e._fulfilled:
                return e
        return None

    def _expect_error(self, fake_name, args, kwargs, exp=None):
        self._had_expectation_error = True
        if exp:
            raise desdixexception.ExpectationException(f'Unexpected call: {fake_name}{args} {kwargs}; expected {exp.fake_name}{exp._args}')
        raise desdixexception.ExpectationException(f'Unexpected call: {fake_name}{args} {kwargs} - no more expectations')

    def _dispatch_everlasting(self, fake_obj, args, kwargs):
        for exp in self._expectations:
            if exp._everlasting and exp._mode == _Expectation.UNORDERED:
                if exp.matches(fake_obj, args, kwargs):
                    return exp.execute_with_result_wrapper()
        return _MISS

    def _dispatch_unordered(self, fake_obj, args, kwargs):
        for exp in self._expectations:
            if not exp._everlasting and exp._mode == _Expectation.UNORDERED and not exp._fulfilled:
                if exp.matches(fake_obj, args, kwargs):
                    return self._fulfill(exp)
        return _MISS

    def _dispatch_ordered(self, fake_obj, args, kwargs):
        exp = self._next_ordered()
        if exp is None or not exp.matches(fake_obj, args, kwargs):
            self._expect_error(object.__getattribute__(fake_obj, '_name'), args, kwargs, exp)
        return self._fulfill(exp)

    def _dispatch_non_ordered(self, fake_obj, args, kwargs):
        result = self._dispatch_everlasting(fake_obj, args, kwargs)
        if result is not _MISS:
            return result
        return self._dispatch_unordered(fake_obj, args, kwargs)

    def dispatch(self, fake_obj, args, kwargs):
        result = self._dispatch_non_ordered(fake_obj, args, kwargs)
        if result is not _MISS:
            return result
        return self._dispatch_ordered(fake_obj, args, kwargs)

    def dispatch_aiter(self, fake_obj):
        for exp in self._async_for_expectations:
            if exp.matches_fake(fake_obj):
                return exp.make_iterator()
        name = object.__getattribute__(fake_obj, '_name')
        raise desdixexception.ExpectationException(f'Unexpected async for on {name}: no expectation set up')


class _ScenarioProxy:
    def __init__(self, scenario, path, mode='call'):
        self._scenario = scenario
        self._path = path
        self._mode = mode

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        return _ScenarioProxy(self._scenario, f'{self._path}.{name}', self._mode)

    def __call__(self, *args, **kwargs):
        fake_obj = fake_module.Fake(self._path)
        exp = _Expectation(fake_obj, args, kwargs, call_type=self._mode)
        return self._scenario._add_expectation(exp)

    def __setitem__(self, key, value):
        child_path = f'{self._path}.__setitem__'
        fake_obj = fake_module.Fake(child_path)
        exp = _Expectation(fake_obj, (key, value), {}, call_type=self._mode)
        self._scenario._add_expectation(exp)

    def __rshift__(self, value):
        raise desdixexception.DesdixError('Unsupported: use __async_for__ to set up async iteration expectations')


class _SpecialProxy:
    def __init__(self, scenario, special_mode):
        self._scenario = scenario
        self._special_mode = special_mode

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        return _SpecialPathProxy(self._scenario, name, self._special_mode)


class _SpecialPathProxy:
    def __init__(self, scenario, path, mode):
        self._scenario = scenario
        self._path = path
        self._mode = mode

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        if self._mode == 'async_for':
            raise desdixexception.DesdixError(f'Unsupported: __async_for__ only works on a plain Fake, not on .{name}')
        return _SpecialPathProxy(self._scenario, f'{self._path}.{name}', self._mode)

    def __call__(self, *args, **kwargs):
        if self._mode == 'async_for':
            raise desdixexception.DesdixError('Unsupported: __async_for__ only works on a plain Fake, not on method calls')
        fake_obj = fake_module.Fake(self._path)
        exp = _Expectation(fake_obj, args, kwargs, call_type=self._mode)
        return self._scenario._add_expectation(exp)

    def __rshift__(self, value):
        if self._mode == 'async_for':
            fake_obj = fake_module.Fake(self._path)
            exp = _AsyncForExpectation(fake_obj, value)
            self._scenario._add_async_for(exp)
            return exp
        raise desdixexception.DesdixError('Unsupported rshift in this context')

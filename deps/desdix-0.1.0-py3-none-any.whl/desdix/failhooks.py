_mode = 'raise'


def setMode(mode):
    global _mode
    _mode = mode


def getMode():
    return _mode

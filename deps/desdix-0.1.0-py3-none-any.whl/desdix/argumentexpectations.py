from . import fake as fake_module


class _ArgumentExpectation:
    pass


class ArgumentIsFakeObjectWithPath(_ArgumentExpectation):
    def __init__(self, path):
        self._path = path

    def matches(self, value):
        return isinstance(value, fake_module.Fake) and object.__getattribute__(value, '_name') == self._path


class IgnoreArgument(_ArgumentExpectation):
    def matches(self, value):
        return True


class IgnoreCallDetails(_ArgumentExpectation):
    pass

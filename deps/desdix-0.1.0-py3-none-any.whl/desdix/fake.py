from . import desdixexception

_registry = {}


def _init_fake(instance, name, fixed_attrs):
    object.__setattr__(instance, '_name', name)
    object.__setattr__(instance, '_fixed_attrs', dict(fixed_attrs))
    object.__setattr__(instance, '_user_attrs', {})
    object.__setattr__(instance, '_pinned_attrs', {})
    object.__setattr__(instance, '_pinned', False)


def _get_or_update_existing(name, fixed_attrs):
    instance = _registry[name]
    if fixed_attrs:
        object.__getattribute__(instance, '_fixed_attrs').update(fixed_attrs)
    return instance


class Fake:
    def __new__(cls, name, **fixed_attrs):
        if name in _registry:
            return _get_or_update_existing(name, fixed_attrs)
        instance = object.__new__(cls)
        _init_fake(instance, name, fixed_attrs)
        _registry[name] = instance
        return instance

    def __repr__(self):
        name = object.__getattribute__(self, '_name')
        return f'Fake({name!r})'

    def __getattr__(self, name):
        for dict_name in ('_fixed_attrs', '_pinned_attrs', '_user_attrs'):
            d = object.__getattribute__(self, dict_name)
            if name in d:
                return d[name]
        my_name = object.__getattribute__(self, '_name')
        return Fake(f'{my_name}.{name}')

    def __setattr__(self, name, value):
        pinned = object.__getattribute__(self, '_pinned')
        dict_name = '_pinned_attrs' if pinned else '_user_attrs'
        d = object.__getattribute__(self, dict_name)
        d[name] = value

    def __call__(self, *args, **kwargs):
        from . import scenario as _scenario
        current = _scenario._current_scenario
        if current is None:
            name = object.__getattribute__(self, '_name')
            raise desdixexception.DesdixError(f'No active scenario when calling Fake({name!r})')
        return current.dispatch(self, args, kwargs)

    def __setitem__(self, key, value):
        name = object.__getattribute__(self, '_name')
        child = Fake(f'{name}.__setitem__')
        child(key, value)

    def __enter__(self):
        from . import scenario as _scenario
        current = _scenario._current_scenario
        if current is None:
            raise desdixexception.DesdixError('No active scenario for __enter__')
        name = object.__getattribute__(self, '_name')
        raise desdixexception.DesdixError(f'Fake({name!r}).__enter__ called unexpectedly')

    def __exit__(self, *args):
        pass

    def __aiter__(self):
        from . import scenario as _scenario
        current = _scenario._current_scenario
        if current is None:
            name = object.__getattribute__(self, '_name')
            raise desdixexception.DesdixError(f'No active scenario for async for on Fake({name!r})')
        return current.dispatch_aiter(self)

    def __rshift__(self, value):
        raise desdixexception.DesdixError('Unsupported: use __async_for__ to set up async iteration expectations')


def _reset_all_user_attrs():
    for fake in _registry.values():
        pinned = object.__getattribute__(fake, '_pinned')
        if not pinned:
            ua = object.__getattribute__(fake, '_user_attrs')
            ua.clear()

class DesdixException(Exception):
    pass


class DesdixError(DesdixException):
    pass


class ExpectationException(DesdixException):
    pass


class ScenarioException(DesdixException):
    pass

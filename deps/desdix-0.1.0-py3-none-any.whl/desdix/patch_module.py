from . import fake as fake_module

_MISSING = object()


class Patcher:
    def __init__(self):
        self._patches = []

    def _make_replacement(self, attr, replacement):
        if replacement is _MISSING:
            fake_obj = fake_module.Fake(attr)
            object.__setattr__(fake_obj, '_pinned', True)
            return fake_obj, fake_obj
        return None, replacement

    def __call__(self, obj, attr, replacement=_MISSING):
        had_attr = hasattr(obj, attr)
        original = getattr(obj, attr, _MISSING)
        fake_obj, new_value = self._make_replacement(attr, replacement)
        setattr(obj, attr, new_value)
        self._patches.append((obj, attr, original, had_attr, fake_obj))

    def _restore_attr(self, obj, attr, original, had_attr):
        if had_attr:
            setattr(obj, attr, original)
        else:
            delattr(obj, attr)

    def _undo_patch(self, obj, attr, original, had_attr, fake_obj):
        self._restore_attr(obj, attr, original, had_attr)
        if fake_obj is not None:
            object.__getattribute__(fake_obj, '_pinned_attrs').clear()
            object.__setattr__(fake_obj, '_pinned', False)

    def undo(self):
        for patch in reversed(self._patches):
            self._undo_patch(*patch)
        self._patches = []
